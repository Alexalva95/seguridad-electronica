<?php
 session_start();
if (isset($_SESSION['usuario'])) {
    header("Location: dashboard.php")   ;
    
    exit ;
}
?>

  <!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
     <title>Seguridad Electrónica</title>
</head>

 <body>
    <h1>Bienvenido a Seguridad Electrónica</h1>
    <p>Portal informativo sobre cámaras y sistemas de seguridad.</p>
       <a href="registro.php">Registrarse</a> | <a href="login.php">Iniciar sesión</a>
</body>
   </html>

