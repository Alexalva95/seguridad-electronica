<?php
session_start();
 if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
     exit;
 }
?>

<!DOCTYPE  html>
 <html  lang="es">
<head>
     <meta charset="UTF-8">
    <title>Panel de Seguridad</title>
     <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px;   }
        h1 { color: #333 ; }
         .producto {
             border: 1px solid  #ccc ;
             padding:  10px ;
            margin-bottom: 15px;
             background: #fff ;
            display: flex;
             align-items: center;
            border-radius: 8px;
        }
        .producto img {
            width: 200px;
             height : auto;
            margin-right: 20px;
            border-radius: 5px ;
        }
        .producto-info            {
             max-width: 600px;
        }
        a.logout   {
            display:  inline-block ;
             margin-top: 10px;
            color: red;
             text-decoration: none;
            font-weight:  bold;
        }
        a.logout:hover {
            text-decoration: underline;
        }
    
      </style>
  </head>

  <body>

<h1>   Bienvenido , <?php echo htmlspecialchars($_SESSION ['usuario']); ?> 👋 </h1>
   <p>  Estos son algunos equipos de seguridad recomendados:  </p>

    <div class="producto">
    <img src="imagenes/imagen1.png"   alt="imagen1">
      <div class="producto-info">
         <h3>Dahua HDCVI 2MP</h3>
        <p> Cámara bullet de alta definición con visión nocturna, ideal para exteriores.  </p>
     </div>

</div>

<div class="producto">
    <img src="imagenes/imagen2.png" alt="imagen2">
     <div class="producto-info" >
        <h3>  Hikvision Dome IP 4MP </h3>
          <p>Cámara tipo domo con conexión IP, compatible con grabación en la nube.   </p>
     </div>
</div>

<div class="producto">
    <img src="imagenes/imagen3.png" alt="imagen3"> 
    
    <div class="producto-info">
        <h3> Dahua PTZ 25X</h3>
        <p>Cámara PTZ con zoom óptico 25x y seguimiento automático de objetos.</p>
    </div>
</div>

<a class="logout" href="logout.php">Cerrar sesión 

 </a>

</body>
 
 </html>