<?php
$host = "localhost";
$usuario = "root";
$clave = "12345.a";  // Cambia si tu contraseña es otra
$bd = "seguridad_db";
$puerto = 3307;

// Crear conexión incluyendo el puerto
$conn = new mysqli($host, $usuario, $clave, $bd, $puerto);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>


