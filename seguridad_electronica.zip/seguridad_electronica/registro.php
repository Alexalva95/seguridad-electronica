
<?php
 include "conexion.php";

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = trim($_POST['nombre']);
    $correo = trim($_POST['correo']) ;

     $clave = $_POST['clave'];

    // Vrificar si el correo ya está registrado 
      $checkSql = "SELECT id FROM usuarios WHERE correo = ?";
    $stmtCheck = $conn->prepare($checkSql);
    $stmtCheck->bind_param("s", $correo)  ;
     $stmtCheck->execute();
    $resultCheck = $stmtCheck->get_result();

      if ($resultCheck->num_rows > 0) {
        echo "<p style='color:red;'>El correo ya está registrado. Intenta con otro.</p>";
    } else {
        $password = password_hash($clave, PASSWORD_DEFAULT);
        $sql = "INSERT INTO usuarios (nombre, correo, password) VALUES (?, ?, ?)"  ;
         $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $nombre, $correo, $password);

        if ($stmt->execute()) {
            echo "<p style='color:green;'>Registro exitoso. <a href='login.php'>Iniciar sesión</a></p>" ;
        } else {
            echo "<p style='color:red;'>Error al registrar: " . $stmt->error . "</p>";
        }
        $stmt->close();
    }
     $stmtCheck->close() ;
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">

 <head>
    <meta charset="UTF-8">
    <title>Registro - Seguridad Electrónica</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f8f8f8; padding: 20px; }
        .contenedor { max-width: 500px; margin: auto; background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px #ccc; }
        img.banner { width: 100%; border-radius: 10px; margin-bottom: 20px; }
        h2 { text-align: center; color: #333; }
        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%; padding: 10px; margin-bottom: 15px; border-radius: 5px; border: 1px solid #ccc;
        }
         button {
            width: 100%; padding: 10px; background: #cc0000; color: #fff; border: none; border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
             background: #a30000;
        }
    </style>
</head>
<body>

 <div class="contenedor">
    <img class="banner" src="imagenes/dahua_banner.png" alt="Dahua Seguridad Electrónica">
      
      <h2>Registro de usuario</h2>
    
    <form method="POST" action="">
         <label>Nombre:</label>
        <input type="text" name= "nombre" required>
        
        <label>Correo:</label>
        <input type="email" name= "correo" required>
        
         <label>Contraseña:</label>
        <input type="password" name= "clave" required>
          <button type="submit">Registrarse</button>
    
    
          </form>
    <p  style="text-align:center; margin-top:10px;" >
        
    ¿Ya tienes cuenta? <a href="login.php">Inicia sesión aquí  </a>
    </p>
</div>

</body>
   </html>

