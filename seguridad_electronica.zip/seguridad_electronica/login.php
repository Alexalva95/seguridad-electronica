

<?php
include  "conexion.php" ;
 session_start();

if (isset ($_SESSION['usuario']))   {
    header("Location: dashboard.php") ;
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $correo = trim($_POST['correo']);
     $clave = $_POST['clave'];

    $sql = "SELECT * FROM usuarios WHERE correo = ?";
       $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $correo);
     $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows === 1) {
        $usuario = $resultado->fetch_assoc()  ;
          if (password_verify($clave, $usuario['password'])) {
            $_SESSION['usuario'] = $usuario['nombre'];
             header("Location: dashboard.php");
            exit;
        } else {
            $error = "Contraseña incorrecta";
        }
    } else {
         $error = "Usuario no encontrado"  ;
    }
    $stmt->close() ;
     $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
 <head>
    <meta charset="UTF-8">
    <title>Login - Seguridad Electrónica</title>
    <style>
         body { font-family: Arial, sans-serif; background: #f8f8f8; padding: 20px; }
        .contenedor { max-width: 400px; margin: auto; background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px #ccc; }
        h2 { text-align: center; color: #333; }
        input[type="email"], input[type="password"] {
            width: 100%; padding:   10px ; margin-bottom: 15px; border-radius: 5px; border: 1px solid #ccc;
        }
        button {
            width: 100%; padding: 10px; background: #cc0000; color: #fff; border:  none; border-radius: 5px ;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background: #a30000 ;
        }
        .error {
            color: red; 
            margin-bottom: 15px ;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="contenedor">
     <h2>Iniciar sesión</h2>

    <?php if (!empty($error)): ?>
        <div class="error"><?php echo htmlspecialchars($error)  ; ?></div>
     <?php endif ; ?>

    <form method="POST" action="">
          <label>Correo:</label>
        <input type="email" name="correo" required>
       
        
         <label>Contraseña:</label>
        <input type="password" name="clave" required>
        
        <button type="submit">Ingresar</button>
    </form>
    
    <p style="text-align:center; margin-top:10px;">
        ¿No tienes cuenta? <a href="registro.php">Regístrate aquí</a>
    </p>
</div>

    </body>
</html>

