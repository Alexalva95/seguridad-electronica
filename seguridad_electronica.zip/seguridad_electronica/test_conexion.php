
<?php
 $conn = new mysqli("localhost", "root", "", "seguridad_db")  ;
if ($conn->connect_error) {
    die( "❌ Falló la conexión: " . $conn->connect_error)  ;}
 echo "✅ Conexión exitosa a MySQL";


?>
